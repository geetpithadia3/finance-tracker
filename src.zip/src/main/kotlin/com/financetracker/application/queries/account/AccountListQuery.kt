package com.financetracker.application.queries.account

class AccountListQuery

package com.financetracker.application.queries.goal

class GoalListQuery

package com.financetracker.domain.account.model

enum class AccountType {
  CHECKING,
  SAVINGS,
  MOMENTUM,
  SCENE
}

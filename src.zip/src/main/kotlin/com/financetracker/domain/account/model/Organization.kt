package com.financetracker.domain.account.model

enum class Organization {
  SCOTIA,
  WEALTHSIMPLE,
  SPLITWISE
}

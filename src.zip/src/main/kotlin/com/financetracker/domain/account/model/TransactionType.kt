package com.financetracker.domain.account.model

enum class TransactionType {
  CREDIT,
  DEBIT
}

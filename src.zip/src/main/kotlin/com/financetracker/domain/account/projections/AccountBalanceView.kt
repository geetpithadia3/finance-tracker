package com.financetracker.domain.account.projections

data class AccountBalanceView(val accountId: String, var amount: Double)
